#!/bin/bash
export TERMINFO=/usr/share/terminfo
export TERM=xterm
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:./.libs/
./bfgminer -o stratum+tcp://mgd.vvpool.com:5630 -u MQVtQD8DMVGoihnXueD4XQLYki1Bnzfj2B -p x -o stratum+tcp://mgd1.dorapool.com:4333 -u MQVtQD8DMVGoihnXueD4XQLYki1Bnzfj2B -p x -S opencl:auto --eexit 1

